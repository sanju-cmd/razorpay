<?php
$keyId = 'rzp_test_tGSZfuUBZOqxbd';
$keySecret = '29zchZSaSEAJLAe7hDWdooRT';
$displayCurrency = 'INR';
error_reporting(E_ALL);
ini_set('display_errors',1);

?>