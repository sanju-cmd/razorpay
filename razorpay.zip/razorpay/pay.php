<?php
require('config.php');
require('razorpay/Razorpay.php');
session_start();
use Razorpay\Api\Api;
$api = new Api($keyId, $keySecret);
$orderData = [
    'receipt'         => 'rcptid_11',
    'amount'          => 39900, // 39900 rupees in paise
    'currency'        => 'INR'
];

$razorpayOrder = $api->order->create($orderData);
$razorpayOrderId = $razorpayOrder['id'];
$_SESSION['razorpay_order_id'] = $razorpayOrderId;
$displayAmount = $amount = $orderData['amount']; 
$checkout = 'manual';
if (isset($_GET['checkout']) and in_array($_GET['checkout'], ['automatic', 'manual'], true))
    {
        $checkout = $_GET['checkout'];
    }
    $data = [
        "key"               => $keyId,
        "amount"            => $amount,
        "name"              => "Aneh Thakur",
        "description"       => "Happy to help :)",
        "image"             => "https://s29.postimg.org/r6dj1g85z/daft_punk.jpg",
        "prefill"           => [
            "name"              => "Aneh Thakur",
            "email"             => "customer email",
            "contact"           => "customer mobile",
        ],
        "notes"             => [
            "address"           => "Customer Address",
            "merchant_order_id" => "12312321",
        ],
        "theme"             => [
            "color"             => "#F37254"
        ],
        "order_id"          => $razorpayOrderId,
    ];

    if ($displayCurrency !== 'INR')
    {
        $data['display_currency']  = $displayCurrency;
        $data['display_amount']    = $displayAmount;
    }
    $json = json_encode($data);
?>

